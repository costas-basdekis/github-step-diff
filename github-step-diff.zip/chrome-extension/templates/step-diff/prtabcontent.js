Templates.register('step-diff/prtabcontent.js', function (ctx) {with (ctx) {return (
`
    <div
            class="tabcontent pr-tab-content is-visible js-tab-content"
            data-tab-group="step-diff"
            data-tab="step-pr"
        >
    </div>
`)}});
